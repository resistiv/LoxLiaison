﻿namespace LoxLiaison.Callable
{
    /// <summary>
    /// Represents the type of a <see cref="LoxClass"/>.
    /// </summary>
    public enum ClassType
    {
        None,
        Class,
        Subclass
    }
}
