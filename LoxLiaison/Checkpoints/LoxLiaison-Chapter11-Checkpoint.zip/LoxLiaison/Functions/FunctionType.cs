﻿namespace LoxLiaison.Functions
{
    public enum FunctionType
    {
        None,
        Function,
    }
}
