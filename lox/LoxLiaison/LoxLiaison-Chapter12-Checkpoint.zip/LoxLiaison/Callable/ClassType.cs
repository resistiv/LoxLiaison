﻿namespace LoxLiaison.Callable
{
    public enum ClassType
    {
        None,
        Class
    }
}
