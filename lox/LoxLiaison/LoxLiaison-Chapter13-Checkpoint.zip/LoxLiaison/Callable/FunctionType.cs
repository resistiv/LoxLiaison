﻿namespace LoxLiaison.Callable
{
    public enum FunctionType
    {
        None,
        Function,
        Initializer,
        Method
    }
}
